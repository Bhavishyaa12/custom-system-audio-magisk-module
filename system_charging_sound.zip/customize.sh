#!/system/bin/sh

ui_print "bhavishyaa_12"

SOUND_FILE="$MODPATH/system/media/audio/ui/ChargingStarted.ogg"

if [ ! -s "$SOUND_FILE" ]; then
	ui_print "No sound file found!!!"
	sleep 1
	ui_print "Exiting"
	abort "Installation aborted"
fi

ui_print "Setting permissions"
set_perm_recursive "$MODPATH/system" 0 0 0755 0644

sleep 1
ui_print "Done! Reboot to apply your changes"
